LD_PRELOAD="./libc-2.27.so ./libcurl.so" ./mirc2077
